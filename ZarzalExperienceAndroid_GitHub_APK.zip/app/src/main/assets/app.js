const page=document.getElementById('page');
function showPage(name){
 const content={
 'Lugares':['Lugares turísticos','Explora espacios naturales, culturales y sitios de interés de Zarzal.','Los destinos específicos se incorporarán después de verificar la información turística local.'],
 'Rutas':['Rutas turísticas','Recorridos propuestos para conocer el municipio.','Ruta 1: Aventura y naturaleza. Ruta 2: Cultura y tradición.'],
 'Pasadías':['Pasadías','Planes para disfrutar un día diferente con familia, amigos o grupos.','Experiencias propuestas: pasadía de aventura y pasadía cultural.'],
 'Gastronomía':['Gastronomía local','Conoce los sabores del Valle del Cauca y la oferta gastronómica de la región.','Próximamente: directorio de restaurantes y comidas tradicionales.'],
 'Contacto':['Contáctanos','Zarzal Experience · Proyecto de emprendimiento turístico.','Ubicación: Zarzal, Valle del Cauca, Colombia.']
 };
 const c=content[name]; page.innerHTML=`<h2>${c[0]}</h2><p>${c[1]}</p><p>${c[2]}</p><button onclick="home()">Volver al inicio</button>`;
 page.classList.remove('hidden'); page.scrollIntoView({behavior:'smooth'});
}
function detail(name){showPage(name)}
function home(){page.classList.add('hidden');window.scrollTo({top:0,behavior:'smooth'})}
